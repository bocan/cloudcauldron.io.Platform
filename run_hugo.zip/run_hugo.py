####################################################
# GitHub zip download, generate public site files and copy to S3.
#
# This code will:
#   * Download a zip file from GitHub Repo.
#   * Unzips files.
#   * Runs the hugo site generator against unzipped files.
#   * Copies generated files to live site's S3 bucket.
#   * Cleanup.
#
####################################################

import boto3
import os
import subprocess
import logging

region_name = 'eu-west-1'
dest_bucket = "cloudcauldron.io"
hugo_theme = "hugo-future-imperfect"
temp_path = '/tmp'
remote_url = "https://github.com/bocan/cloudcauldron.io.git"
github_zip = 'https://github.com/bocan/cloudcauldron.io/archive/master.zip'
github_name = 'cloudcauldron.io-master'
unzipped_files_path = "{0}/{1}".format(temp_path, github_name)   # /tmp/bocan_hugo_site-master
zipped_file_path = '{0}.zip'.format(unzipped_files_path)         # /tmp/bocan_hugo_site-master.zip
dest_tmp = "{0}/public".format(unzipped_files_path)              # /tmp/bocan_hugo_site-master/public

#logging.getLogger('run_hugo')
#logger = logging.Logger('run_hugo')
#logger.setLevel(logging.DEBUG)

# s3 client and resource
client = boto3.client('s3', region_name=region_name)
resource = boto3.resource('s3', region_name=region_name)


def subprocess_cmd(cmd):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    if err:
        logging.error(">>>>> cmd [E]{0}".format(err))
    else:
        logging.info(">>>>> cmd {0}".format(out))


def publish_files(s3_client, s3_resource, dest_bucket, root_dir, dest_temp):

    # remove all files and folders except index.html
    for parent_dir, sub_dir_list, file_list in os.walk(root_dir):
        # logging.info(parent_dir)
        # logging.info(sub_dir_list)
        # logging.info(file_list)
        for file in file_list:
            if not file.startswith("."):
                full_path = parent_dir + "/" + file
                s3_path = full_path.replace(dest_temp + "/", '')
                extension = os.path.splitext(file)[1]
                content_type = "text/" + extension.replace(".", '')
                logging.info(">>>>> in {0}".format(s3_path))
                s3_resource.meta.client.upload_file(full_path, dest_bucket, s3_path, ExtraArgs={'ContentType': content_type})

        for sub_dir in sub_dir_list:
            if not sub_dir.startswith("."):
                full_path = parent_dir + "/" + sub_dir
                s3_path = full_path.replace(dest_temp + "/", '')
                logging.info(">>>>> in {0}".format(s3_path))
                publish_files(s3_client, s3_resource, dest_bucket, parent_dir + "/" + sub_dir, dest_temp)

        break


def lambda_handler(event, context):
    # get content for hugo from github
    logging.info(">>> START github content dowload")
    subprocess_cmd('curl -L -o {0} {1}'.format(zipped_file_path, github_zip))  # curl works by default; wget does not
    subprocess_cmd('ls -lah {0}'.format(temp_path))
    subprocess_cmd('unzip -o {0} -d {1}'.format(zipped_file_path, temp_path))
    logging.info(">>> DONE github content dowload")

    # run hugo
    logging.info(">>> START run hugo command")
    subprocess_cmd("./hugo --theme={0} --source={1} -v".format(hugo_theme, unzipped_files_path))
    logging.info(">>> DONE run hugo command")

    # remove files from the dest_bucket to get only the files needed
    logging.info(">>> START publish_files")
    publish_files(client, resource, dest_bucket, dest_tmp, dest_tmp)
    logging.info(">>> DONE publish_files")

    # cleanup
    logging.info(">>> START cleanup".format(unzipped_files_path))
    if os.path.isfile(unzipped_files_path):
        os.unlink(unzipped_files_path)
    os.unlink(zipped_file_path)
    logging.info(">>> DONE cleanup")

    return "Update Site Complete."

